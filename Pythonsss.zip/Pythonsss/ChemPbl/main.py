from chem import Equation
from time import sleep

def run_balance():
    print('============================================')
    print('enter chemical equation in the correct format:')
    equation=input('>>>')
    balanced_equation=Equation(equation).balance()
    print('\n')
    print(balanced_equation)
    sleep(5)
    run_balance()

run_balance()