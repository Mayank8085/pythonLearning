x=int(input("enter first no"))
y=int(input('enter 2 no'))
z=x+y
print(z)
ch=input('enter a char')[0]
print(ch)
result=eval(input('flksjfh'))
print(result)
