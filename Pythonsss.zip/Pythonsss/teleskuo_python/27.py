a=10
def some():
    a=9
    x=globals()['a']
    globals()['a']=15
    print(id(x))
    print('in fun',a)
    



some()


print('gobal',a)
print(id(a))