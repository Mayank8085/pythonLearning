from numpy import *
arr1=array([
            [1,2,3,5,9,0],
            [4,5,6,8,9,8]
            ])
print(arr1)
print(arr1.dtype)
print(arr1.ndim)
print(arr1.shape)
print(arr1.size)
arr2=arr1.flatten()
print(arr2)
x=arr2.reshape(3,4)
print(x)
y=arr2.reshape(2,2,3)
print(y)
m=matrix(arr1)
print(m)
n=matrix(int('3,4,2,4 ; 5,7,9'))
print(n)