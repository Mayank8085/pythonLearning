from demo import sum




def fun1():
    print("from fun1")
    sum()

def fun2():
    print("from fun2")


def main():
    fun1()
    fun2()

         
main()
    