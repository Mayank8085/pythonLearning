class a:
    def __init__(self):
        print('in a init')

    def feat1(self):
        print('this is fest 1')

    def feat2(self):
        print('this is fest 2')




class b:
    def __init__(self):
        #super().__init__()
        print('in b init')
    def feat1(self):
        print('this is fest 3')

    def feat4(self):
        print('this is fest 4')



class c(a,b):
    def __init__(self):
        super().__init__()
        print('in c init')
    def feat5(self):
        super().feat4()
        print('this is fest 5')





a1=c()
a1.feat1()
a1.feat5()

