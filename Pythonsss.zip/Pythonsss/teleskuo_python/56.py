f=open('Desktop\mayank\ma.txt','r')
f1=open('Desktop\mayank\ca.txt','a')
#f1.write('something')
#f1.write("sum")
#print(f.readline(),end="")
#print(f.readline())
for data in f:
    f1.write(data)

f2=open('Desktop\mayank\may.PNG','rb')
f3=open("Desktop\mayank\sah.PNG",'wb')
for i in f2:
    f3.write(i)  