i=1
while i<=5:
    print('mayank', end="")

    j=1
    while j<=5:
        print('sahu',end='')
        j+=1
    i+=1
    print()
    
