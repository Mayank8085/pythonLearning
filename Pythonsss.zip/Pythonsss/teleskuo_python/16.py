from array import *
aa=array('i',[])
x=int(input('enter the length of array'))
for i in range(x):
    a=int(input('enter the next value'))
    aa.append(a)

print(aa)

value=int(input('enter the value'))
k=0
for e in aa:
    if e==value:
        print(k)
        break
    k+=1
print(aa.index(value))