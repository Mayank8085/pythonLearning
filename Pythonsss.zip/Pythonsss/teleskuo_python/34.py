from functools import reduce


nums=[1,2,3,4,5,6,7,8,9,10]

even = list(filter(lambda n:n%2==0,nums))
double=list(map(lambda n:n*2,even))
su = reduce(lambda a,b:a+b,double)


print(even)
print(double)
print(su)