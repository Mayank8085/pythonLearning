def person(name,age=18):# actual argument a,b
    print(name)
    print(age)
        
person('mayank')
def add(x,*b):
    z=x
    for i in b:
        z=z+i
    print(z)

add(5,6,7,34,36)


