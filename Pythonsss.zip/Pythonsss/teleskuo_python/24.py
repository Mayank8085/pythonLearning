def person(name,age=18):# actual argument a,b
    print(name)
    print(age)

person(name='mayank')
def sum(a,*b):
    c=a
    for i in b:
        c=c+i
    print(c)

sum(4,5,6,7,9,10)