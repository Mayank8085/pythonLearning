x='mayank'
for i in x:
    print(i)
for i in range(11,21,2):
    print(i)
for i in range(20,11,-1):
    print(i)
for i in range(1,21):
    if i%5!=0:
        print(i)
        
