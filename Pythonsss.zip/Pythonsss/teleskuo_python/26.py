def person(name,**data):
    print(name)
    for i,j in data.items():
        print(i,j)



person('mayank',age=19,city='nagpur',mobile=9307531964)    