x=int(input())
if x==1:
    print('one')
elif x==2:
    print('two')
elif x==3:
    print('three')
else:
    print('wrong input')
    
 
 