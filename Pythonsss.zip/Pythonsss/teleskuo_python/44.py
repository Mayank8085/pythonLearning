class student:
    school='telusko'

    def __init__(self,m1,m2,m3):
        self.m1=m1
        self.m2=m2
        self.m3=m3

    def avg(self):
        return(self.m1+self.m2+self.m3)/3

    def getm1(self):
        return self.m1

    def setm1(self,value):
        self.m1=value
    
    @classmethod
    def getschool(cls):
        return cls.school


    @staticmethod
    def info():
        print("this is class")


    





s1=student(12,34,23)
s2=student(34,56,43)

print(s1.avg())
print(s2.avg())
s2.setm1(55)
print(s2.getm1())
print(student.getschool())
student.info()