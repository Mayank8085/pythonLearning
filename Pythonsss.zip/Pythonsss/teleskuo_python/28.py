l=[]
n= int(input('enter the length'))
print(n)
for i in range(n):
    x=int(input('enter the value'))
    l.append(x)

print(l)
def count(a):

     even=0
     odd=0
     for i in l:

         if i%2==0:
             even+=1
         else:
             odd+=1
     return even,odd

even,odd=count(l)
print ('even={} and odd={}'.format(even,odd))  