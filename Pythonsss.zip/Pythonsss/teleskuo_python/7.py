x=int(input('the no'))
r=x%2
if r==0:
    print("even")
    if x>5:
        print('greater than 5')
    else: 
        print('not')
     
else:
    print('odd')
    
print('bye')

