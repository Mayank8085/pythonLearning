from numpy import *
arr= array([1,2,3,4,5])
arr1=array([6,7,8,9,10])
arr3= arr+arr1
print(arr3)

print(log(arr))
print(sum(arr))
print(min(arr))
print(max(arr))
print(concatenate([arr,arr1]))
a=arr.view()
b= arr.copy()
arr[1]= 0
print(b)
print(id(b))
print(a) 
print(arr)
print(id(a))
print(id(arr))