from cal import *

a=9
b=7

c= add(a,b)

print(c)