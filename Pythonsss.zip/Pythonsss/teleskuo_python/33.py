f = lambda a,b: a+b

result=f(5,7)
print(result)