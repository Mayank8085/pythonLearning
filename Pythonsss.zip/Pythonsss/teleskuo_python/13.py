nums= [12,16,18,23,26]

for i in nums:
    if i%5==0:
        print(i)
        break
else:
    print('not found')