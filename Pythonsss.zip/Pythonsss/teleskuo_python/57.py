arr=[5,8,4,6,9,2]
n=4
pos=-1
def search(list,n):
    i=0
    while i<len(list):
        if list[i]==n:
           globals() ['pos']=i
           return True

        i=i+1

    return False
if search(arr,n):
    print('found at',pos+1)

else:
    print("not found")


    
    
