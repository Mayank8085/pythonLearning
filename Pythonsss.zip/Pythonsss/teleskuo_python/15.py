from array import *
value=array('i',[5,6,-9,8])
new  = array(value.typecode,[a*a for a in value])
print(new)
for i in range(len(value)):
    print(value[i])
for e in value:
    print(e)
i=0
while i<len(new):
    print(new[i])
    i+=1
    