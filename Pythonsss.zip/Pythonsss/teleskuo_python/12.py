for i in range(4):
    for i in range(4):
        print('#',end=" ")
    print()
for i in range(4):
    for i in range(i+1):
        print('#',end=" ")
    print()
for i in range(4):
    for i in range(4-i):
        print('#',end=" ")
    print()