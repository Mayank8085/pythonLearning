def sum():
    print("this is sum")

def sub():
    print("this is sub")

def main():
    sub()
    sum()
 
 

if __name__ == "__main__":
    main()


