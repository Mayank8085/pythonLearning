nums =[7,8,9,5]


it =iter(nums)
print(it.__next__())
print(it.__next__())

print(next(it))

for i in nums:
    print(i)


class topten:
    def __init__(self):
        self.nums=1

    def __iter__(self):
        return self

    def __next__(self):
        if self.nums<=10:
            val=self.nums
            self.nums+=1
            
            return val

        else:
            raise StopIteration


valu=topten()

print(next(valu))

for i in valu:
    print(i)