x=int(input('how many cadny '))
av=5
i=1
while i<=x:
    if i>av:
        print('out of stock')
        break
    print('candy',end='')
    i+=1

print('bye')
for i in range(1,50):
    if i%3==0 and i%5==0:
        continue
    print(i)
for i in range (1,50):
    if i%2!=0:
        pass
    else :
        print(i)

print('hello')
