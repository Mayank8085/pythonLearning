class computer:
    def config(self):
        print('i5,16gb,1TB')



comp1=computer()
comp2=computer()
print(type(comp1))
comp1.config()
computer.config(comp1)
comp2.config()