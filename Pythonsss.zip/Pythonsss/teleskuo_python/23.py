def update(x):
    print(id(l))
    l[1]=25
    print(id(l))
    print('x', l)

l=[10,20,30]

update(5)
