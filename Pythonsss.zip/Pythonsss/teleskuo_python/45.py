class student:
    def  __init__(self,name,rolln):
        self.name=name
        self.rollno=rolln
        self.lap =self.laptop()

    def show(self):
        print(self.name,self.rollno)
        self.lap.sew()

    class laptop:
        def __init__(self):
            self.brand='dell'
            self.cpu='i5'
            self.ram=8
        def sew(self):
            print(self.cpu,self.brand)



s1=student('nmnmnm',9)
s1.show()
#lap1=student.lapi()
#lap1.sew()


   

