a=5
b=2
try:
    print("resource open")
    print(a/b)
    k=int(input('enter a number'))
    print(k)

#except Exception as e:
except ZeroDivisionError as e:
    print("no can not divide by zero",e)

except ValueError as e:
    print("invalid input",e)


except Exception as e:
    print('something wrong')

finally:
    print("resource closed")





