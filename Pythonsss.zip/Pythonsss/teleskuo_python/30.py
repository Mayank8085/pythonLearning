x=int(input('enter the no'))

def fact(n):
    a=1
    for i in range(1,n+1):
        
        a=a*i
    return a
result = fact(x)
print(result)
