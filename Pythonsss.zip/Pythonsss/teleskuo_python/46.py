class a:
    def feat1(self):
        print('this is fest 1')

    def feat2(self):
        print('this is fest 2')


class b(a):
    def feat3(self):
        print('this is fest 3')

    def feat4(self):
        print('this is fest 4')


class c(b):
    def feat5(self):
        print('this is fest 5')

    def feat6(self):
        print('this is fest 6')

class d():
    def feat7(self):
        print('this is fest 7')
class e(a,d):
    def feat8(self):
        print('this is fest 8')



    

a1=a()
a1.feat1()
b1=b()
b1.feat3()
c1=c()
c1.feat1()
e1=e()
e1.feat7()
