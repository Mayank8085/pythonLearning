from sahu import *


  
print('demo says',__name__)
