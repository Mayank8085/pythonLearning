arr=[5,8,4,6,9,2]
n=int(input('enter the no want to search \n'))
pos=0

def search(list,n):
    i=0
    for i in list:
        if i==n:
           globals() ['pos']=list.index(i)
           return True

        

    
if search(arr,n):
    print('found at',pos+1)

else:
    print("not found")