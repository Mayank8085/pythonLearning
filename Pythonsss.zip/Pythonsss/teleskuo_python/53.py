def topten():
    n=1
    while n<=10:
        sq=n*n
        yield sq
        n+=1
    
    #yield 1
    #yield 2
    #yield 3
    #yield 4



val=topten()
print(val.__next__())
print(val.__next__())
for i in val:
    print(i)