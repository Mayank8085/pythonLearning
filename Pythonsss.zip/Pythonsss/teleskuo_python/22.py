def m() :
    print('hello')

m()
def add():
    x=int(input('enter the first no'))
    y=int(input('enter the second  no'))
    z=x+y
    return z

result=add()
print(result)
def add_sub(x,y):
    c=x+y
    d=x-y
    return c,d
a=add_sub(5,6)
print(a)