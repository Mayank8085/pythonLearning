class mytype:
    def execute(self):
        print('complilng')
        print('running')

class my:
    def execute(self):
        print('complilng')
        print('running')
        print('hello')




class laptop:
    def code(self,a):
        a.execute()


b=my()
lap=laptop()
lap.code(b)
