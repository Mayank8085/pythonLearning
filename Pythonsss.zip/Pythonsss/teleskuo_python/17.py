from numpy import *
arr=array([1,2,3,4])
print(arr)