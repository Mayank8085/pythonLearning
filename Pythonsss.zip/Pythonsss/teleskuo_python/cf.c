#include<stdio.h>
void main()
{
    printf("this is cf");
}