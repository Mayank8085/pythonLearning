from numpy import *
m=matrix('1,2 ; 4,5')
n=matrix('2,3 ; 4,9')
print(m)
print(m.max())
a=m*n
print(a)
print(m.diagonal())
