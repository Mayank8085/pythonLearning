#selection sort
nums=[5,3,8,6,7,2]



def sort(nums):
    min=nums[0]
    
    for i in range(0,len(nums)-1,1):
        minpos=i

        for j in range(i,len(nums)):
            if nums[j]<nums[minpos]:
                minpos=j


        t=nums[i]
        nums[i]=nums[minpos]
        nums[minpos]=t

        print(nums)

        

sort(nums)
