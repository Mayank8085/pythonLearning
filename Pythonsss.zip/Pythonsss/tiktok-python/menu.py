from tkinter import *
from tkinter import ttk
root=Tk()
def open():
    print("open was clicked")

def close():
    print('close was clicked')

menu=Menu(root)
root.config(menu=menu)
subMenu=Menu(menu,tearoff=0)
menu.add_cascade(label="file",menu=subMenu)

subMenu.add_command(label="open",command=open)
subMenu.add_separator()
subMenu.add_command(label="close",command=close)

subMenu2=Menu(menu,tearoff=0)
menu.add_cascade(label="edit",menu=subMenu2)

subMenu2.add_command(label="undo")
subMenu2.add_separator()
subMenu2.add_command(label="redo")


root.mainloop()
