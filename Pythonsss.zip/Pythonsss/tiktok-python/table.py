from tkinter import *
root=Tk()

def table():
    number=entry.get()
    two=int(number)*2
    three=int(number)*3
    four=int(number)*4
    five=int(number)*5
    six=int(number)*6
    seven=int(number)*7
    eight=int(number)*8
    nine=int(number)*9
    ten=int(number)*10






    labelText1.set(number+'x'+'1='+number)
    labelText2.set(number + 'x' + '2=' + str(two))
    labelText3.set(number + 'x' + '3=' +str(three))
    labelText4.set(number + 'x' + '4=' + str(four))
    labelText5.set(number + 'x' + '5=' + str(five))
    labelText6.set(number + 'x' + '6=' +str(six))
    labelText7.set(number + 'x' + '7=' +str(seven))
    labelText8.set(number + 'x' + '8=' +str(eight))
    labelText9.set(number + 'x' + '9=' +str(nine))
    labelText10.set(number + 'x' + '10=' +str(ten))









entry=Entry(root)
entry.pack()
Button(root,text="show table",command=table).pack()
labelText1=StringVar()
labelText1.set('=============')
Label(root,textvariable=labelText1,bg='green').pack()

labelText2=StringVar()
labelText2.set('=============')
Label(root,textvariable=labelText2,bg='yellow').pack()

labelText3=StringVar()
labelText3.set('=============')
Label(root,textvariable=labelText3,bg='brown').pack()

labelText4=StringVar()
labelText4.set('=============')
Label(root,textvariable=labelText4,bg='pink').pack()

labelText5=StringVar()
labelText5.set('=============')
Label(root,textvariable=labelText5,bg='blue').pack()

labelText6=StringVar()
labelText6.set('=============')
Label(root,textvariable=labelText6,bg='gold').pack()

labelText7=StringVar()
labelText7.set('=============')
Label(root,textvariable=labelText7,bg='red').pack()

labelText8=StringVar()
labelText8.set('=============')
Label(root,textvariable=labelText8,bg='orange').pack()

labelText9=StringVar()
labelText9.set('=============')
Label(root,textvariable=labelText9,bg='grey').pack()

labelText10=StringVar()
labelText10.set('=============')
Label(root,textvariable=labelText10,bg='indigo').pack()











root.mainloop()
