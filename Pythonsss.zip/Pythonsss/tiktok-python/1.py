from tkinter import *
from tkinter import messagebox
def changeRed() :
    labelText.set('red')
    label.config(bg='red')

def changeGreen() :
    labelText.set('green')
    label.config(bg='green')

def changeBlue() :
    labelText.set('blue')
    label.config(bg='blue')


def show():
    Text.set(entry.get())
    entry.delete(0,END)

def showwet():
    print(buttonvalue.get())

root=Tk()
labelText=StringVar()
labelText.set('label')
label=Label(root,textvariable=labelText)
label.pack()
Button(root,text='red',command=changeRed).pack()
Button(root,text='green',command=changeGreen).pack()
Button(root,text='blue',command=changeBlue).pack()
Label(root,text="which you want").pack()
Checkbutton(root,text="pen").pack()
Checkbutton(root,text="pencil").pack()
Checkbutton(root,text="eraser").pack()
entry=Entry(root,bg="red",fg='blue')
entry.pack()
Text=StringVar()
Text.set(('========'))
Button(root,text='show on label',command=show).pack()
label1=Label(root,textvariable=Text)
label1.pack()
buttonvalue=StringVar()
Label(root,text="choose your favourite colour").pack()
Radiobutton(root,text="summer",value='dry',variable=buttonvalue).pack()
Radiobutton(root,text="winter",value='winter',variable=buttonvalue).pack()
Radiobutton(root,text='rainy',value='rainy',variable=buttonvalue).pack()
Radiobutton(root,text="wet",value='4',variable=buttonvalue).pack()
Button(root,text='show the selected weather',command=showwet).pack()



#def buttonTaped():
    #messagebox._show('message','button clicked')
#myLabale = Label(root,text="my 1 label")
#myLabale.pack()
#Button(root,text="click me",command=buttonTaped).pack()
root.mainloop()