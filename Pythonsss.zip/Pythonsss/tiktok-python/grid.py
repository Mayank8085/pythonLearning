from tkinter import *
from  tkinter import ttk
root=Tk()
label1=Label(root,text="label1",bg='yellow')
label1.grid(row=0,column=0,ipadx=50,ipady=50)#remeber also pad option

label2=Label(root,text="label2",bg='blue')
label2.grid(row=0,column=1,sticky=N+S+E+W)

label3=Label(root,text="label3",bg='red')
label3.grid(row=1,column=0,sticky=N+S)

label4=Label(root,text="label4",bg='green')
label4.grid(row=1,column=1,ipadx=50,ipady=50)







root.mainloop()

