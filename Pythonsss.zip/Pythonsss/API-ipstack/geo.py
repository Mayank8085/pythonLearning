import urllib.request, urllib.parse, urllib.error
import json
import ssl

# Ignore SSL certificate errors
ctx = ssl.create_default_context()
ctx.check_hostname = False
ctx.verify_mode = ssl.CERT_NONE

ip = input("Enter IP Address: ")

service = "http://api.ipstack.com/"
access_key = "9fc870d9c53b7a754132089151f5d647"

url = service + ip + "?access_key=" + access_key

uh = urllib.request.urlopen(url, context=ctx)

data = uh.read().decode()


js = json.loads(data)

print("continent_name:", js["continent_name"])
print("country_name:", js["country_name"])
print("city:", js["city"])
print("Zip:", js["zip"])
print("Latitude:", js["latitude"])
print("capital:", js["location"]["capital"])
print("Language:", js["location"]["languages"][0]["name"])
# print("country_flag:", js["location"]["country_flag"])
# print("current_time:", js["time_zone"]["current_time"])
# print("currency:", js["currency"]["name"])
