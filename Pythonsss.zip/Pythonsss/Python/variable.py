# n=3
s=''' \
this is a string
line after line
of text and more
text.
'''
print(s)
print(id(s))