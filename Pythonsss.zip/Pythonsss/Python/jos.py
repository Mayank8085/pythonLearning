a=6
b=5
a,b=b,a
print(a,b)



