def main():
	s='this is a string'
	for c in s:
		if c=='s':continue
		print(c,end='',)
		print()

	d='this is python'
	for a  in d:
		if a=='p':break
		print(a, end='')
	
if __name__ =='__main__': main()