def main():
	for x in [1,2,3,4,5]:
		print(x, end=' ')
		print()

		s=[1,2,3,4] 
	for x,y in enumerate (s):
		print(x,y)
		e='this is string'
	for x,y in enumerate(e):
		 	if y=='s': print('index{} is an s' .format(x)) 
		 		 		 
	
		
	a,b=0,1
	while b<50:
		print(b, end=' ')
		a,b=b,a+b
 	
  		
if __name__ == '__main__': main()
	