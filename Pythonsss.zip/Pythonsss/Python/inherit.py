class animal:
    def walk(self):print('i am walking')
    def cloth(self):print('i have cloth')
    
class Duck(animal):
    def quack(self):
        print('Quaaack!')

    def walk(self):
        print('Walks like a duck.')
class dog(animal):
    def cloth(self):
        print('i have fur')
def main():
    donald = Duck()

    donald.cloth()
    donald.walk()
    steefy = dog()
    steefy.walk()
    steefy.cloth()

if __name__ == "__main__": main()
