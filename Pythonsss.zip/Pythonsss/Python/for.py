# read the lines from tne file
fh=open("lines.txt")
for line in fh.readlines():
    print(line, end="" )

