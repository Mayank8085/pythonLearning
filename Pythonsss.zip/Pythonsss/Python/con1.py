class Duck:
    def __init__(self,value):
        self.v = value
    def quack(self):
        print('Quaaack!',self.v)

    def walk(self):
        print('Walks like a duck.')

def main():
    donald = Duck(2343)
    fuk= Duck(45)
    print(donald)
    donald.quack()
    donald.walk()
    fuk.quack()
    fuk.walk()

if __name__ == "__main__": main()
