def main():
	x=(1,2,3)
	print(type(x), x)
	for i in x:
			print(i)
	y=[1,2,3,4]
	y.append(5)
	y.insert(0,7)
	y.insert(1,9)
	for i in y:
		print(i)
	a="string"
	for i in a:
		print(i)
    
	print(type(a),a[2:5])

	print(type(y),y)






if __name__=="__main__": main()