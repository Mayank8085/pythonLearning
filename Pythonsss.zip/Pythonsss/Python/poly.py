class Duck:
    def quack(self):
        print('Quaaack!')

    def walk(self):
        print('Walks like a duck.')
    def fur(self):
        print('duck has fur')

class dog:
    def quack(self):
        print('wohh')

    def walk(self):
        print('walk like a dog')
    def fur(self):
        print('dog has fur')

def main():
    donald = Duck()
    sheru=dog()
    in_the_forest(donald)
    in_the_sea(sheru)



def in_the_forest(gg):
    gg.fur()
    gg.walk()
def in_the_sea(ff):
    ff.quack()

   
    

if __name__ == "__main__": main()
