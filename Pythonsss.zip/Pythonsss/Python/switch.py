def main():
	choices=dict(
		one= 'first' ,
		two= 'second' ,
		three= 'third' ,
		four= 'fourth' ,
		five= 'fifth'
    )
	a='one'
	print(choices[a])
	b="four"
	print(choices.get(b,'other'))
	p,q=0,1
	s='this is true' if p<q else 'this is not true'
	print(s)

if __name__=="__main__": main()