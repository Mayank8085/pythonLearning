print("hello world")#this is simple print statement
a=(1,2,3,4,5)#this is tuple
