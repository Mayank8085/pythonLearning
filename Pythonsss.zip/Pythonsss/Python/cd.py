
ch=input('enter a char')[0]
print(ch)