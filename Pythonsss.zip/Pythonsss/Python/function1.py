def main():
    testfunc(2,3,5,67,9,one=1,two=2)

def testfunc(this,that, do,*args,**kwargs):
    print("this is function test ",
    this,that,do,kwargs["one"] )
    for n in args:print(n)
    for k in kwargs: print(k,kwargs[k])
    

if __name__=="__main__":main()   