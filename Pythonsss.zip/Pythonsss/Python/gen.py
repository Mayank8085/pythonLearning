def main():
    print("thi is just a file"),
    for i in inclusive(0,25,2,7):
        print(i, end=" ")

def inclusive(*args):
    num=len(args)
    if num<1 : raise TypeError("at least one arg require")
    elif num == 1:
        stop=args[0]
        start=0
        step=1
    elif num ==2:
        (start,stop)=args
        step=1
    elif num ==3:
        (start, stop,step)=args
    else:raise TypeError('more arg')
    i = start
    while i<= stop:
        yield i
        i += step

if __name__=="__main__":main()        

        